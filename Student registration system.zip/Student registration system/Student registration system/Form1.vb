﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

        Dim num As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            num = CInt(TextBox3.Text)
            If num > 10 Or num < 10 Then
                MsgBox("length must be 10")
            Else
                MsgBox("msgbox succesfull ")
            End If
        Catch ex As Exception
            MsgBox("enter only numbers ")
            MsgBox("there was an error ", ex.ToString)
            MsgBox(ex.Message)


End Class
