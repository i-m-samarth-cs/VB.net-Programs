﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For i = 0 To ListBox1.SelectedItem.count
            If ListBox1.SelectedItems.Count = 0 Then
                Label1.Text = "No subject selected"

            Else
                ListBox1.Text = String.Join(" ", ListBox1.SelectedItems.OfType(Of String))
            End If

        Next
    End Sub
End Class
