﻿Imports System.ComponentModel
Imports System.Text.RegularExpressions

Public Class Form1
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox1_Validating(sender As Object, e As CancelEventArgs) Handles TextBox1.Validating
        Dim expression As New Regex("\b\d{10}$")
        If TextBox1.Text = "" Then
            ErrorProvider1.SetError(sender, "Cannot Be Empty ")
            e.Cancel = True
        ElseIf expression.IsMatch(TextBox1.Text) Then
            ErrorProvider1.SetError(sender, " ")
        Else
            ErrorProvider1.SetError(sender, "Not a Valid Number")
            e.Cancel = True
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox2_Validating(sender As Object, e As CancelEventArgs) Handles TextBox2.Validating
        Dim expression As New Regex("\S+@\S+.\S+")
        If TextBox2.Text = "" Then
            ErrorProvider1.SetError(sender, "Cannot Be Empty ")
            e.Cancel = True
        ElseIf expression.IsMatch(TextBox2.Text) Then
            ErrorProvider1.SetError(sender, " ")
        Else
            ErrorProvider1.SetError(sender, "Not a Valid Email Must Contain @ Symbol and Domain Name")
            e.Cancel = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MessageBox.Show("Submit Succesfully")
    End Sub
End Class
