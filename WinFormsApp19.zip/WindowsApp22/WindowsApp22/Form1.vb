﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        <!DOCTYPE HTML>
<html>
<head><title>My Blog</title></head>
<body><div align = "center" >
<h1><center><mark><b>My Blog about my life</b></mark><center></h1>
<h2><b>Meeting With my supervisor</b></h2>
<b>14 Dec 2011</b><br>
Today I went to the university by bus<br>

I had a met with my PhDsupervisor<br>

<h2><b>New Car</b></h2>
<b>13 Dec 2011</b><br>
Today I bought my New car .It's Honda Accord and it's really nice.<br>

        I met some friends at a pub<br>

<h2><b>Visit my parents</b></h2>
<b>10 Dec 2011</b><br>

Tried to contact my PhD supervisor.He was out of his office<br>

I visited my parents And we had a nice dinner together<br>
Contact Me:<a href = "pmk@gmail.com" ></a>
        </div>

<div classalign = "left" >

<h2><b>Menu</b></h2>

<u>Today</u><br>
<u>Yesterday</u><br>
<u>Last week</u><br>
<u>Archieves</u><br>

</div>
<div classalign = "right" >








</body>
</html>

    End Sub
End Class
