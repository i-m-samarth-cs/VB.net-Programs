﻿Imports System.Data.SqlClient

Public Class Form1
    Dim cn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim dt As DataTable
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New SqlConnection("Data Source=.;Initial Catalog=vb;Integrated Security=True")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        da = New SqlDataAdapter
        dt = New DataTable
        cmd = New SqlCommand("select * from Student1 where Student_id=" & Val(TextBox1.Text) & " ", cn)
        cn.Open()
        da.SelectCommand = cmd
        da.Fill(dt)
        cn.Close()

        TextBox1.Text = dt.Rows(0).Item(0)
        TextBox2.Text = dt.Rows(0).Item(1)
        TextBox3.Text = dt.Rows(0).Item(2)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        cmd = New SqlCommand("insert into Student1 values(" & Val(TextBox1.Text) & ",'" & TextBox2.Text & "','" & TextBox3.Text & "')", cn)
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MessageBox.Show("Records Inserted Succefully")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        cmd = New SqlCommand("update Student1 set Student_name='" & TextBox2.Text & " ',Student_branch= '" & TextBox3.Text & " 'where Student_id=" & Val(TextBox1.Text) & "", cn)
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MessageBox.Show("Records Updated Succefully")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        cmd = New SqlCommand("delete from Student1 where Student_id=" & Val(TextBox1.Text) & " ", cn)
        cn.Open()
        da.SelectCommand = cmd
        da.Fill(dt)
        cn.Close()
        MsgBox("Records Deleted Succefully")
    End Sub
End Class
