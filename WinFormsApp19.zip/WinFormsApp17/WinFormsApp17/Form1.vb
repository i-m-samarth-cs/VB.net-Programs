﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim avg As Double
        BackColor = red
        avg = (Double.Parse(ComboBox1.SelectedItem) + (ComboBox2.SelectedItem)) / 2
        MsgBox("Average is" & avg)
    End Sub
End Class
