﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.VbDataSet = New WindowsApp17.vbDataSet()
        Me.VBBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VBTableAdapter = New WindowsApp17.vbDataSetTableAdapters.VBTableAdapter()
        Me.StudidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudbranchDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VbDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VBBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudidDataGridViewTextBoxColumn, Me.StudnameDataGridViewTextBoxColumn, Me.StudbranchDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.VBBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(258, 138)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(418, 160)
        Me.DataGridView1.TabIndex = 0
        '
        'VbDataSet
        '
        Me.VbDataSet.DataSetName = "vbDataSet"
        Me.VbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VBBindingSource
        '
        Me.VBBindingSource.DataMember = "VB"
        Me.VBBindingSource.DataSource = Me.VbDataSet
        '
        'VBTableAdapter
        '
        Me.VBTableAdapter.ClearBeforeFill = True
        '
        'StudidDataGridViewTextBoxColumn
        '
        Me.StudidDataGridViewTextBoxColumn.DataPropertyName = "Stud_id"
        Me.StudidDataGridViewTextBoxColumn.HeaderText = "Stud_id"
        Me.StudidDataGridViewTextBoxColumn.Name = "StudidDataGridViewTextBoxColumn"
        '
        'StudnameDataGridViewTextBoxColumn
        '
        Me.StudnameDataGridViewTextBoxColumn.DataPropertyName = "Stud_name"
        Me.StudnameDataGridViewTextBoxColumn.HeaderText = "Stud_name"
        Me.StudnameDataGridViewTextBoxColumn.Name = "StudnameDataGridViewTextBoxColumn"
        '
        'StudbranchDataGridViewTextBoxColumn
        '
        Me.StudbranchDataGridViewTextBoxColumn.DataPropertyName = "Stud_branch"
        Me.StudbranchDataGridViewTextBoxColumn.HeaderText = "Stud_branch"
        Me.StudbranchDataGridViewTextBoxColumn.Name = "StudbranchDataGridViewTextBoxColumn"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VbDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VBBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents VbDataSet As vbDataSet
    Friend WithEvents VBBindingSource As BindingSource
    Friend WithEvents VBTableAdapter As vbDataSetTableAdapters.VBTableAdapter
    Friend WithEvents StudidDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StudnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StudbranchDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
