﻿Imports System.Data.SqlClient
Public Class Form1
    Dim com As SqlConnection
    Dim cmd As SqlCommand
    Dim ds As New DataSet()
    Dim adpt As SqlDataAdapter
    Dim d As New DataSet()
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        com = New SqlConnection("Data Source=.;Initial Catalog=vb;Integrated Security=True")
        com.Open()
        adpt = New SqlDataAdapter("Select * from VB", com)
        adpt.Fill(d, "VB")
        DataGridView1.DataSource = d
        DataGridView1.DataMember = "VB"

    End Sub
End Class
