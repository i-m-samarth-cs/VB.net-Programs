﻿Imports System.Data.SqlClient
Public Class Form1
    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim adapt1, adapt2, adapt3 As SqlDataAdapter
    Dim ds As New DataSet()
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New SqlConnection("Data Source=.;Initial Catalog=vb;Integrated Security=True")
        adapt1 = New SqlDataAdapter("select * from Student", con)
        adapt2 = New SqlDataAdapter("select * from Employee", con)
        adapt3 = New SqlDataAdapter("select * from City", con)

        adapt1.Fill(ds, "Student")
        adapt2.Fill(ds, "Employee")
        adapt3.Fill(ds, "City")

        DataGridView1.DataSource = ds
        DataGridView1.DataMember = "Student"
        DataGridView2.DataSource = ds
        DataGridView2.DataMember = "Employee"
        DataGridView3.DataSource = ds
        DataGridView3.DataMember = "City"
    End Sub
End Class
