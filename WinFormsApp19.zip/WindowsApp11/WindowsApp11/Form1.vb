﻿Imports System.Text.RegularExpression

Public Class Form1
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox1_Validating(sender As Object, e As CancelEventArgs) Handles TextBox1.Validating
        If TextBox1.Text = " " Then
            ErrorProvider1.SetError(TextBox1, "Please Enter a Username")
            e.Cancel = True
            If IsNumeric(TextBox1.Text) Then
                ErrorProvider1.Seterror(TextBox1, "PLease enter only Characters")
                e.Cancel = True
            Else
                ErrorProvider1.SetError(TextBox1, "")
            End If
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox2_Validating(sender As Object, e As CancelEventArgs) Handles TextBox2.Validating
        If TextBox2.Text = " " Then
            ErrorProvider1.SetError(TextBox2, "Please Enter Password")
            e.Cancel = True
            If (Len(TextBox2.Text) < 6) Then
                ErrorProvider1.SetError(TextBox2, "PLease enter a Strong Password More than 6 Characters")
                e.Cancel = True
            Else
                ErrorProvider1.SetError(TextBox2, "")
            End If
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MessageBox.Show("Login Successfully")
    End Sub
End Class
