﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim Stud_idLabel As System.Windows.Forms.Label
        Dim Stud_nameLabel As System.Windows.Forms.Label
        Dim Stud_branchLabel As System.Windows.Forms.Label
        Me.VbDataSet = New WindowsApp18.vbDataSet()
        Me.VBBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VBTableAdapter = New WindowsApp18.vbDataSetTableAdapters.VBTableAdapter()
        Me.TableAdapterManager = New WindowsApp18.vbDataSetTableAdapters.TableAdapterManager()
        Me.VBBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.VBBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.VBDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Stud_idTextBox = New System.Windows.Forms.TextBox()
        Me.Stud_nameTextBox = New System.Windows.Forms.TextBox()
        Me.Stud_branchTextBox = New System.Windows.Forms.TextBox()
        Stud_idLabel = New System.Windows.Forms.Label()
        Stud_nameLabel = New System.Windows.Forms.Label()
        Stud_branchLabel = New System.Windows.Forms.Label()
        CType(Me.VbDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VBBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VBBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.VBBindingNavigator.SuspendLayout()
        CType(Me.VBDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VbDataSet
        '
        Me.VbDataSet.DataSetName = "vbDataSet"
        Me.VbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VBBindingSource
        '
        Me.VBBindingSource.DataMember = "VB"
        Me.VBBindingSource.DataSource = Me.VbDataSet
        '
        'VBTableAdapter
        '
        Me.VBTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = WindowsApp18.vbDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VBTableAdapter = Me.VBTableAdapter
        '
        'VBBindingNavigator
        '
        Me.VBBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.VBBindingNavigator.BindingSource = Me.VBBindingSource
        Me.VBBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.VBBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.VBBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.VBBindingNavigatorSaveItem})
        Me.VBBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.VBBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.VBBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.VBBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.VBBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.VBBindingNavigator.Name = "VBBindingNavigator"
        Me.VBBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.VBBindingNavigator.Size = New System.Drawing.Size(800, 25)
        Me.VBBindingNavigator.TabIndex = 0
        Me.VBBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 15)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'VBBindingNavigatorSaveItem
        '
        Me.VBBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.VBBindingNavigatorSaveItem.Image = CType(resources.GetObject("VBBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.VBBindingNavigatorSaveItem.Name = "VBBindingNavigatorSaveItem"
        Me.VBBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 23)
        Me.VBBindingNavigatorSaveItem.Text = "Save Data"
        '
        'VBDataGridView
        '
        Me.VBDataGridView.AutoGenerateColumns = False
        Me.VBDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.VBDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3})
        Me.VBDataGridView.DataSource = Me.VBBindingSource
        Me.VBDataGridView.Location = New System.Drawing.Point(285, 115)
        Me.VBDataGridView.Name = "VBDataGridView"
        Me.VBDataGridView.Size = New System.Drawing.Size(407, 220)
        Me.VBDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Stud_id"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Stud_id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Stud_name"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Stud_name"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Stud_branch"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Stud_branch"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'Stud_idLabel
        '
        Stud_idLabel.AutoSize = True
        Stud_idLabel.Location = New System.Drawing.Point(118, 105)
        Stud_idLabel.Name = "Stud_idLabel"
        Stud_idLabel.Size = New System.Drawing.Size(43, 13)
        Stud_idLabel.TabIndex = 2
        Stud_idLabel.Text = "Stud id:"
        '
        'Stud_idTextBox
        '
        Me.Stud_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VBBindingSource, "Stud_id", True))
        Me.Stud_idTextBox.Location = New System.Drawing.Point(167, 102)
        Me.Stud_idTextBox.Name = "Stud_idTextBox"
        Me.Stud_idTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Stud_idTextBox.TabIndex = 3
        '
        'Stud_nameLabel
        '
        Stud_nameLabel.AutoSize = True
        Stud_nameLabel.Location = New System.Drawing.Point(100, 147)
        Stud_nameLabel.Name = "Stud_nameLabel"
        Stud_nameLabel.Size = New System.Drawing.Size(61, 13)
        Stud_nameLabel.TabIndex = 4
        Stud_nameLabel.Text = "Stud name:"
        '
        'Stud_nameTextBox
        '
        Me.Stud_nameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VBBindingSource, "Stud_name", True))
        Me.Stud_nameTextBox.Location = New System.Drawing.Point(167, 144)
        Me.Stud_nameTextBox.Name = "Stud_nameTextBox"
        Me.Stud_nameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Stud_nameTextBox.TabIndex = 5
        '
        'Stud_branchLabel
        '
        Stud_branchLabel.AutoSize = True
        Stud_branchLabel.Location = New System.Drawing.Point(93, 202)
        Stud_branchLabel.Name = "Stud_branchLabel"
        Stud_branchLabel.Size = New System.Drawing.Size(68, 13)
        Stud_branchLabel.TabIndex = 6
        Stud_branchLabel.Text = "Stud branch:"
        '
        'Stud_branchTextBox
        '
        Me.Stud_branchTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VBBindingSource, "Stud_branch", True))
        Me.Stud_branchTextBox.Location = New System.Drawing.Point(167, 199)
        Me.Stud_branchTextBox.Name = "Stud_branchTextBox"
        Me.Stud_branchTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Stud_branchTextBox.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Stud_branchLabel)
        Me.Controls.Add(Me.Stud_branchTextBox)
        Me.Controls.Add(Stud_nameLabel)
        Me.Controls.Add(Me.Stud_nameTextBox)
        Me.Controls.Add(Stud_idLabel)
        Me.Controls.Add(Me.Stud_idTextBox)
        Me.Controls.Add(Me.VBDataGridView)
        Me.Controls.Add(Me.VBBindingNavigator)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.VbDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VBBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VBBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.VBBindingNavigator.ResumeLayout(False)
        Me.VBBindingNavigator.PerformLayout()
        CType(Me.VBDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents VbDataSet As vbDataSet
    Friend WithEvents VBBindingSource As BindingSource
    Friend WithEvents VBTableAdapter As vbDataSetTableAdapters.VBTableAdapter
    Friend WithEvents TableAdapterManager As vbDataSetTableAdapters.TableAdapterManager
    Friend WithEvents VBBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents VBBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents VBDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents Stud_idTextBox As TextBox
    Friend WithEvents Stud_nameTextBox As TextBox
    Friend WithEvents Stud_branchTextBox As TextBox
End Class
