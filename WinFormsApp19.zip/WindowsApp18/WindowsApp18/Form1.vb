﻿Public Class Form1
    Private Sub VBBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles VBBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.VBBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.VbDataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'VbDataSet.VB' table. You can move, or remove it, as needed.
        Me.VBTableAdapter.Fill(Me.VbDataSet.VB)

    End Sub
End Class
