﻿
Imports System.Text.RegularExpressions
Public Class Form1
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Dim Expresssions As New Regex("(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((18|19|20)\d\d))$")
        If Expressions.Ismatch(TextBox1.Text) Then
            ErrorProvider1.SetError(sender, " ")
        Else
            ErrorProvider1.SetError(sender, "date not valid")
        End If
    End Sub
End Class
