﻿Public Class Form1
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Label4.Visible = True
        Label6.Visible = True
        Label7.Visible = True
        Dim str As String
        str = str & "Semester is " & ComboBox1.SelectedItem.ToString

        For i = 0 To ListBox1.SelectedItems.Count
            If ListBox1.SelectedItems.Count = 0 Then
                Label7.Text = "No Subject Selected"
            Else
                Label7.Text = String.Join(" ", ListBox1.SelectedItems.OfType(Of String))

            End If
        Next
        Label6.Text = str
        Label4.Text = TextBox1.Text

    End Sub

    Private Sub ListBox1_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label4.Visible = False
        Label6.Visible = False
        Label7.Visible = False

    End Sub
End Class
