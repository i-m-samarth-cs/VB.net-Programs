﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For i = 0 To ListBox1.SelectedItems.Count
            If ListBox1.SelectedItems.Count = 0 Then
                Label1.Text = "No Subject Selected"
            Else
                Label1.Text = String.Join(" ", ListBox1.SelectedItems.OfType(Of String))

            End If

        Next
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub
End Class
