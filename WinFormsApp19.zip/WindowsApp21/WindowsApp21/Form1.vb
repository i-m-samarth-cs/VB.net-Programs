﻿Imports System.Data.SqlClient
Public Class Form1
    Dim cn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim dt As DataTable

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New SqlConnection("Data Source=.;Initial Catalog=vb;Integrated Security=True")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd = New SqlCommand("insert into Registration values(" & Val(TextBox1.Text) & ",'" & TextBox2.Text & "','" & TextBox3.Text & "')", cn)
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MsgBox("Student Registered Succefully")
    End Sub
End Class
