﻿Public Class Form1
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        PictureBox1.ClientSize = New Size(612, 510)
        PictureBox1.Image = Image.FromFile("C:\Users\GPD\Desktop\OIP (1).jpg")

    End Sub
End Class
