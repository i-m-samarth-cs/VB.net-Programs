﻿Public Class Form1
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim College As String
        College = ComboBox1.Text
        MessageBox.Show("Your Selected College is:" & College)
    End Sub
End Class
