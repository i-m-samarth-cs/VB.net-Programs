﻿Public Class Form1
    Dim num As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try

            num = CInt(TextBox2.Text)
            If (num == 10) Then
                MsgBox("********Registered Succefully******")
            ElseIf (num > 10 ro num<10)
                MsgBox("Length Must be 10")
            End If
        Catch ex As Exception
        MsgBox("Their Was an Error" & ex.ToString)
        MsgBox("Enter only Numbers")
        End Try

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Try

        Catch h As System.ArrayTypeMismatchException
            MsgBox("Enter Proper Name")
        End Try
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        Try

        Catch f As System.ArrayTypeMismatchException
            MsgBox("Enter Correct Rollno")
        End Try
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        Try

        Catch g As System.ArrayTypeMismatchException
            MsgBox("Enter Proper Email ID")
        End Try
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged


    End Sub
End Class
