﻿Module Module1
    Class Student
        Overridable Sub Show()
            Dim rollno As Integer
            rollno = 230
            Console.WriteLine("Roll NO:" & rollno)

        End Sub
    End Class
    Class Faculty
        Inherits Student
        Public Overrides Sub Show()
            MyBase.Show()
            Dim faculty As String
            faculty = "Computer"
            Console.WriteLine("Faculty:" & faculty)
        End Sub
    End Class
    Sub Main()
        Dim o As New Faculty()
        o.Show()
        Console.ReadLine()
    End Sub
End Module
