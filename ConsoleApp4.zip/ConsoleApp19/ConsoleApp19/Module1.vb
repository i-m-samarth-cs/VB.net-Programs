﻿Module Module1
    Function Recursion(ByVal n As Integer) As Integer
        Dim num As Integer
        num = 1
        num += 1
        Console.WriteLine(num)
        Recursion(num)
        Return num
    End Function
    Sub Main()
        Recursion(while(no<5))
    End Sub

End Module
