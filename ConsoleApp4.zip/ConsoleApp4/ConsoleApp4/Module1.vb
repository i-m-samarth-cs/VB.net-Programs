﻿Module Module1

    Sub Main()
        Dim i As Integer
        i = 0
        Do
            i += 1
            Console.WriteLine(i)

        Loop While (i < 5)
        Console.ReadLine()
    End Sub

End Module
