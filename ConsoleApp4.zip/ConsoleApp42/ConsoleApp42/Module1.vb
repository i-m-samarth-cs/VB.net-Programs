﻿Imports System
Module Module1
    Class P1
        Public Shared s1 As String

        Overloads Sub accept()
            Console.WriteLine("Enter 1st String")
            s1 = Console.ReadLine()
        End Sub
    End Class
    Class P2
        Inherits P1
        Public Shared s2 As String
        Overloads Sub accept(s As String)
            s2 = s1
            Console.WriteLine(s2)
        End Sub
        Sub concate()
            Dim value3 = s1 + " " + s2
            Console.WriteLine("Concated Strings are:" & value3)
        End Sub
    End Class
    Sub Main()
        Dim p As New P2()
        p.accept()
        p.accept("Samarth")
        p.concate()
        Console.ReadLine()
    End Sub
End Module