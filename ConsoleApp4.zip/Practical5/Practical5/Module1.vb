﻿Module Module1

    Sub Main()
        Dim c As Char
        Console.WriteLine("Enter Any Charcter:")
        c = Console.ReadLine()
        Select Case c
            Case "A", "a", "E", "e", "I", "O", "o", "U", "u"
                Console.WriteLine("Character is Vowel")
                Console.ReadLine()
            Case Else
                Console.WriteLine("Character is Consonant")
                Console.ReadLine()
        End Select
    End Sub

End Module
