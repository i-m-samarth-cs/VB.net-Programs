﻿Module Module1
    Class person
        Public name As String
        Public city As String
        Public age As Integer
        Sub getData(n As String, c As String, a As Integer)
            name = n
            city = c
            age = a
        End Sub
        Overridable Sub print()
            Console.WriteLine("Employee details :")
            Console.WriteLine("Name :" & name)
            Console.WriteLine("City :" & city)
            Console.WriteLine("Age :" & age)
        End Sub
        Sub display()
            MyClass.print()
        End Sub
    End Class
    Class employee
        Inherits person
        Public salary As Integer
        Sub acceptSalary(s As Integer)
            salary = s
        End Sub
        Public Overrides Sub print()
            MyBase.print()
            Console.WriteLine("Salary :" & salary)
        End Sub


    End Class

    Sub Main()
        Dim o As New employee()
        o.getData("pratham", "navapue", 18)
        o.acceptSalary(5000000)
        o.display()
        o.print()

        Console.Read()
    End Sub

End Module


