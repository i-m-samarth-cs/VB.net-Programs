﻿Module Module1

    Sub Main()
        Dim i As Integer
        i = 0
        While (i < 5)
            i += 1
            Console.WriteLine(i)

        End While
        Console.ReadLine()
    End Sub

End Module
