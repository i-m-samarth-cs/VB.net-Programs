﻿Module Module1
    Class Person
        Public age As Integer
        Public Name, city As String
        Sub getData(a As Integer, n As String, c As String)
            age = a
            Name = n
            city = c
        End Sub
        Overridable Sub showData()
            Console.WriteLine("Employee Details")
            Console.WriteLine("Name=" & Name)
            Console.WriteLine("Age=" & age)
            Console.WriteLine("City=" & city)
        End Sub
        Sub display()
            MyClass.showData()
        End Sub
    End Class
    Class Employee
        Inherits Person
        Dim salary As Double
        Sub acceptSalary(s As Double)
            salary = s
        End Sub
        Public Overrides Sub showData()
            Console.WriteLine("Salary-" & salary)
        End Sub
    End Class
    Sub Main()
        Dim obj As New Employee()
        obj.getData(18, "Samarth", "Dhule")
        obj.acceptSalary(20000.0)
        obj.display()
        obj.showData()
        Console.ReadLine()
    End Sub

End Module
