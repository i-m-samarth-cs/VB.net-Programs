﻿
Module Module1
    Sub Main()
        Dim a As Integer
        Dim B As Integer
        Dim C As Integer
        a = 10
        B = 0
        Try
            C = a / B
            Throw New Exception(C)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
End Module
