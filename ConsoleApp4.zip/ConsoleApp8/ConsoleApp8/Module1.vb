﻿Module Module1

    Sub Main()
        Dim num, i As Integer
        num = 5
        For i = 1 To num
            Console.WriteLine(i)
        Next i
        Console.ReadLine()


    End Sub

End Module
