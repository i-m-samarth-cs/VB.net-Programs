﻿Module Module1
    Class student
        Dim name As String
        Public Sub New()
            name = "pratham"
            Console.WriteLine("hello")


        End Sub
        Public Sub display()
            Console.WriteLine(" ")

        End Sub

    End Class

    Sub Main()

        Dim s As New student
        s.display()



    End Sub

End Module
