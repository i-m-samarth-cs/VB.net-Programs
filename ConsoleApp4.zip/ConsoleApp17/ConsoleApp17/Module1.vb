﻿Public Module Module1
    Function Fibonacci(ByVal n As Integer) As Integer
        Dim val1 As Integer = 0
        Dim val2 As Integer = 1
        Dim i As Integer
        For i = 0 To n - 1
            Dim temp As Integer = val1
            val1 = val2
            val2 = temp + val2
        Next
        Return val1
    End Function

    Sub Main()
        For i As Integer = 0 To 20
            Console.WriteLine(Fibonacci(i))
            Console.Write(" ")
        Next
    End Sub
End Module