﻿Module Module1
    Class Area
        Private r As Double
        Public Sub New(ByVal temp As Double)
            r = temp

        End Sub
        Public Function getarea() As Double
            Dim aoc As Double
            aoc = Math.PI * r * r
            Return aoc


        End Function
    End Class
    Sub Main()
        Dim a As New Area(5.0)
        Console.WriteLine("area of circle is :" & a.getarea())
        Console.ReadLine()
    End Sub

End Module
