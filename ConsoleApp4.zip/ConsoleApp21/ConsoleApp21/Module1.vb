﻿Module Module1

    Class box
        Public l, b, h As Integer
    End Class


    Sub Main()
        Dim obj As box = New box()
        Dim volume As Double


        obj.l = 6.0
        obj.b = 5.0
        obj.h = 7.0
        volume = obj.l * obj.b * obj.h
        Console.WriteLine("volume =" & volume)

    End Sub

End Module
