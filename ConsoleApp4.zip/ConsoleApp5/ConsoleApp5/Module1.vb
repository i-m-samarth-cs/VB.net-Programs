﻿Module Module1

    Sub Main()
        Dim num, div As Integer
        Dim i As Long

        num = 0
        While (num < 100)
            num += 1
            div = 0
            For i = 1 To num
                If (num Mod i = 0) Then
                    div += 1
                End If
            Next i
            If (div=2)Then
                Console.WriteLine(num & "Is Prime Number")
            End If

        End While
        Console.ReadLine()
    End Sub

End Module
