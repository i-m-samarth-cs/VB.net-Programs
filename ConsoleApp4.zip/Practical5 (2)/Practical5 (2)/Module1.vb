﻿Module Module1

    Sub Main()
        Dim a, b, c, d As Integer

        Do While (1)
            Console.WriteLine("********Menu*********")
            Console.WriteLine("1.Addition")
            Console.WriteLine("2.Subtraction")
            Console.WriteLine("3.Multiplcation")
            Console.WriteLine("4.Division")
            Console.WriteLine("5.Exit")

            Console.WriteLine("Enter Choice(1/2/3/4/5)")
            d = Console.ReadLine()

            Console.WriteLine("Enter Any 2 Number:")
            a = Console.ReadLine()
            b = Console.ReadLine()




            Select Case d
                Case 1
                    Console.WriteLine("Addition is" & a + b)
                    Console.ReadLine()

                Case 2
                    Console.WriteLine("Subtraction is" & a - b)
                    Console.ReadLine()

                Case 3
                    Console.WriteLine("Multiplication is" & a * b)
                    Console.ReadLine()

                Case 4
                    Console.WriteLine("Division is" & a / b)
                    Console.ReadLine()

                Case 5
                    End
                Case Else
                    Console.WriteLine("Invalid Choice")
            End Select
        Loop

    End Sub

End Module
