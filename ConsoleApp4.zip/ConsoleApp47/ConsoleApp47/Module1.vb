﻿Imports System.Data.SqlClient
Imports System.Console

Module Module1
    Dim con As New SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Sub Main()
        con = New SqlConnection("Data Source=.;Initial Catalog=vb;Integrated Security=True")
        con.Open()
        cmd = New SqlCommand("select * from VB", con)
        dr = cmd.ExecuteReader
        Do While dr.Read()
            Console.WriteLine("Student_name:" & dr(0))
            Console.WriteLine("Syudetn_id" & dr(1))
            Console.WriteLine("Student_branch" & dr(2))
        Loop
        dr.Close()
        con.Close()
        ReadLine()
    End Sub

End Module
