﻿Module Module1

    Sub Main()
        Dim num As Integer
        num = 0
        Console.WriteLine("Even Numbers")
        While (num < 50)
            num += 1
            If (num Mod 2 = 0) Then
                Console.WriteLine(num)
            End If
        End While
        Console.ReadLine()
    End Sub

End Module
