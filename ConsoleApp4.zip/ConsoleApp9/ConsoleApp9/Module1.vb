﻿Module Module1

    Sub Main()
        Dim arr As Array = {1, 2, 3, 4, 5}
        Dim i As Integer
        For Each i In arr
            Console.WriteLine(i)
        Next
        Console.ReadLine()
    End Sub

End Module
