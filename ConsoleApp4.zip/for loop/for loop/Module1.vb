﻿Module Module1

    Sub Main()
        Dim i As Integer
        i = 1

        For i = 1 To 5

            Console.WriteLine(i)

            i += 5


        Next i
        Console.ReadLine()
    End Sub

End Module
