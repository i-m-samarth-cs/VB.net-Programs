﻿Module Module1
    Class Area
        Private r As Double
        Public Sub New(ByVal temp As Double)
            r = temp
        End Sub
        Public Function getArea() As Double
            Return 3.14 * r * r
        End Function
    End Class
    Sub Main()
        Dim a As New Area(5.0)
        Console.Write("Area of Circle :{0}", a.getArea())
        Console.ReadKey()
    End Sub
End Module
