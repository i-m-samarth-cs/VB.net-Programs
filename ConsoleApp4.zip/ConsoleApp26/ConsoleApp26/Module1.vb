﻿Class Student
    Dim name As String
    Public Sub New()
        name = "Samarth"
        MsgBox(name)


    End Sub
End Class
Module Module1

    Public Sub Main()
        Dim s As New Student

    End Sub

End Module
