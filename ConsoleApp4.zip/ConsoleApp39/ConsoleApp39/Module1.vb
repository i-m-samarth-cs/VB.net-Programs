﻿Module Module1
    Class Faculty
        Private name, department As String
        Sub getInfo()
            Console.WriteLine("Enter Name of Faculty ")
            name = Console.ReadLine()
            Console.WriteLine("Enter Department ")
            department = Console.ReadLine()

        End Sub
        Sub showInfo()
            Console.WriteLine("Name of Faculty -" & name)
            Console.WriteLine("Department -" & department)
        End Sub

    End Class
    Public Class Student
        Inherits Faculty
        Private rollno As Integer
        Private a As String
        Sub getData()
            Console.WriteLine("Enter Name of Student ")
            a = Console.ReadLine()
            Console.WriteLine("Enter Rollno of Student")
            rollno = Console.ReadLine()

        End Sub
        Sub showData()
            Console.WriteLine("Name of Student- " & a)
            Console.WriteLine("Roll No -" & rollno)
            Console.ReadLine()
        End Sub
    End Class
    Sub Main()
        Dim s As New Student()
        s.getInfo()
        s.getData()
        s.showInfo()
        s.showData()
    End Sub

End Module
