﻿Module Module1
    Public Class String1
        Sub getInfo(S As String
                    )


    End Class
    Sub Main()

    End Sub

End Module
