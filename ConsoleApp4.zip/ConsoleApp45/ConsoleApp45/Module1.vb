﻿Module Module1
    Sub Main()
        Try
            Dim a As Integer
            Dim b As Integer
            Dim value As Double
            Console.WriteLine("Enter any 2 Numbers:")
            a = Console.ReadLine()
            b = Console.ReadLine()
            value = a / b

        Catch e As System.DivideByZeroException
            Console.WriteLine(e.Message)
            Console.WriteLine("Division is:" & value)
            Console.ReadLine()

        End Try
    End Sub
End Module
