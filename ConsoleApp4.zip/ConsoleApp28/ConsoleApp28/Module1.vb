﻿Public Module Module1
    Public Class Book
        Public Sub Main()
            Dim S As New Studentbooksale()
        End Sub
    End Class
    Public Class Booksale
        Sub New()
            Console.WriteLine(“My Base Class”)
        End Sub
    End Class
    Public Class Studentbooksale
        Inherits Booksale
        Sub New()
            MyBase.New()
            Console.WriteLine(“My child Class”)
        End Sub
    End Class

End Module