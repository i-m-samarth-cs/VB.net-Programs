﻿Public Module Module1
    Class Box
        Public L, B, H As Double
    End Class
    Sub Main()
        Dim BOx1 As Box = New Box()
        Dim volume As Double
        BOx1.H = 5.0
        BOx1.B = 7.0
        BOx1.L = 6.0
        volume = BOx1.L * BOx1.B * BOx1.H
        Console.WriteLine("Volume is" & volume)
        Console.ReadLine()
    End Sub
End Module
