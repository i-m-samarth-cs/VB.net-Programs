




Module Module1
        Public Class Faculty
            Public name As String
            Public no As Integer
            Sub getinfo()

                Console.WriteLine("Enter faculty name :")
                name = Console.ReadLine()
                Console.WriteLine("Enter faculty no :")
                no = Console.ReadLine()

            End Sub
            Sub showinfo()
                Console.WriteLine(" faculty name :" & name)
                Console.WriteLine("faculty no :" & no)

            End Sub
        End Class
        Public Class Student
            Inherits Faculty
            Public name1 As String
            Public rno As Integer
            Sub getData()
                Console.WriteLine("Enter student name :")
                name1 = Console.ReadLine()
                Console.WriteLine("Enter rollno :")
                rno = Console.ReadLine()
            End Sub

            Sub showData()
                Console.WriteLine(" student name :" & name1)
                Console.WriteLine("student rollno :" & rno)

            End Sub

        End Class
        Sub Main()
            Dim a As New Student()
            a.getinfo()
            a.showinfo()
            a.getData()
            a.showData()

            Console.ReadLine()

        End Sub

    End Module
