﻿Module Module1

    Sub Main()
        Dim num As Integer
        num = 0
        Console.WriteLine("Odd Numbers")
        While (num < 50)
            num += 1
            If (num Mod 2 = 1) Then
                Console.WriteLine(num)
            End If
        End While
        Console.ReadLine()
    End Sub

End Module
