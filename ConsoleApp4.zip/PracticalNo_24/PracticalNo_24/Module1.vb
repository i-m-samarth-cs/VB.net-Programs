﻿Imports System.Data.SqlClient
Imports System.Console

Module Module1
    Dim con As New SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataAdapter

    Sub Main()
        con = New SqlConnection("Data Source=.;Initial Catalog=Student;Integrated Security=True")
        con.Open()
        cmd = New SqlCommand("select * from Student", con)
        dr = cmd.ExecuteReader
        Do While dr.Read()
            WriteLine("Name   : " & dr(0))
            WriteLine("Roll NO: " & dr(1))
            WriteLine("BHranch: " & dr(2))
        Loop
        dr.close()
        con.Close()
        ReadLine()

    End Sub

End Module
