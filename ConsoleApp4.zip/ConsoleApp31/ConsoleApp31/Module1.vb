﻿Module Module1

    Public Class Faculty
        Public name As String
        Public rn As Integer

        Public Function acceptinfo(ByVal n As String, ByVal num As Integer)
            name = n
            no = num

            Console.WriteLine("enter foculty name :")
            name = Console.ReadLine()
            Console.WriteLine("enter foculty no :")
            no = Console.ReadLine()



        End Function


        End Sub
    End Class

    Public Class student
        Inherits Faculty
        Public name1 As String
        Public rn As Integer

        Public Sub New(ByVal na As String, ByVal roll As Integer)
            name1 = na
            rn = roll

            MyBase.New(, )
            Console.WriteLine("student name:" & name1)
            Console.WriteLine("student rollno:" & rn)

            End Function
        End Sub
    End Class

End Module
