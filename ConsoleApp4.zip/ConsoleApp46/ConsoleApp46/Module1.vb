﻿Module Module1
    Dim a As Integer
    Dim b As Integer
    Public value As Double
    Class Exception
    End Class
    Sub Main()
        Try

            Console.WriteLine("Enter any 2 Numbers:")
            a = Console.ReadLine()
            b = Console.ReadLine()
            value = a \ b

        Catch e As System.DivideByZeroException
            Console.WriteLine(e.Message)
        End Try
        Console.WriteLine("Division is:" & value)
        Console.ReadLine()
    End Sub
End Module

