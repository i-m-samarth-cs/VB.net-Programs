﻿Imports System
Namespace Student
    Public Class Academics
        Public Sub Percentage()
            Dim Total As Integer
            Dim Percentage As Single
            Console.WriteLine("Give Total Marks Out of 850")
            Total = Integer.Parse(Console.ReadLine())
            Percentage = Total / 850 * 100
            Console.WriteLine("Percentage=" & Percentage & "%")
        End Sub
    End Class
    Public Class Sports
        Public Sub Score()
            Dim Score As Integer
            Console.WriteLine("Give Score Out of 10")
            Score = Integer.Parse(Console.ReadLine())
            Console.WriteLine("Score=" & Score)
        End Sub
    End Class
End Namespace
Module Module1

    Sub Main()
        Dim Ac As Student.Academics = New Student.Academics()
        Dim Sp As Student.Sports = New Student.Sports()
        Ac.Percentage()
        Sp.Score()
    End Sub

End Module
