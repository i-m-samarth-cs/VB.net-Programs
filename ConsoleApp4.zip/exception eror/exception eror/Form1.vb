﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Integer
        Dim b As Integer
        Dim c As Integer
        a = TextBox1.Text
        b = TextBox2.Text

        Try
            c = a / b
            MsgBox("division is " & c)
        Catch ex As Exception
            MsgBox("something made wrong please enter another no ")
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
