﻿Public Module Module1
    Function Reverse(ByVal n As Integer)
        Dim rev As Integer = 0
        Dim rem1 As Integer = 0
        Dim num As Integer

        num = n
        While (num > 0)
            rem1 = num Mod 10
            rev = (rev * 10) + rem1
            num = num / 10
        End While
        Console.WriteLine(rev)
    End Function
    Sub Main()
        Dim num2 As Integer
        Console.WriteLine("Enter any Number:")
        num2 = Integer.Parse((Console.ReadLine()))
        Reverse(num2)
    End Sub

End Module
